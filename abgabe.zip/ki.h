#ifndef ki
#define ki

#include "random_ki.h"

char* getBestMove(char my_brett[FIELD_SIZE][FIELD_SIZE][MAX_TOWER_SIZE]);

#endif